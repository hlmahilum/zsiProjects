 
    if(window.location.hash.length < 1 ) {  
        window.location.replace(base_url + "page/home#p/dashboard");      
    }
 