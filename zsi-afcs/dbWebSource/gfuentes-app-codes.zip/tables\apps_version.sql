CREATE TABLE apps_version(
zPayVersion	DECIMAL(10)	NULL
,zFareVersion	DECIMAL(10)	NULL)