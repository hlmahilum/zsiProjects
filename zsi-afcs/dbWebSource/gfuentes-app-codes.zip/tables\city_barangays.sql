CREATE TABLE city_barangays(
barangay_id	INT IDENTITY(1,1)	NOT NULL
,barangay_name	NVARCHAR(100)	NULL
,city_id	INT	NULL)