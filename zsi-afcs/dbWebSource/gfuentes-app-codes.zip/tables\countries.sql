CREATE TABLE countries(
country_id	INT IDENTITY(1,1)	NOT NULL
,country_code	NCHAR(20)	NULL
,country_name	NVARCHAR(200)	NULL)