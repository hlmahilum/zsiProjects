CREATE TABLE monthly_collection_summary(
id	INT	NOT NULL
,client_id	INT	NULL
,collection_month	INT	NULL
,collection_year	INT	NULL)