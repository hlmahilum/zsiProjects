CREATE TABLE name_suffixes(
name_suffix	NCHAR(20)	NULL)