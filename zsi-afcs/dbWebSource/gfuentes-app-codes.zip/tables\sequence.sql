CREATE TABLE sequence(
seq_no	INT	NULL)