CREATE TABLE states(
state_id	INT IDENTITY(1,1)	NOT NULL
,state_name	NVARCHAR(100)	NULL
,country_id	INT	NULL)