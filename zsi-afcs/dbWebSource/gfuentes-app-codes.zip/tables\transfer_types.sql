CREATE TABLE transfer_types(
transfer_type_id	INT IDENTITY(1,1)	NOT NULL
,transfer_type	NCHAR(20)	NULL)