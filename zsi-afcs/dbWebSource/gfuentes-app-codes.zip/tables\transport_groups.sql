CREATE TABLE transport_groups(
transport_group_id	INT IDENTITY(1,1)	NOT NULL
,transport_group	NVARCHAR(100)	NULL)