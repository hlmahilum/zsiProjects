CREATE TABLE vehicles_active(
vehicle_hash_key	NVARCHAR(200)	NULL
,client_id	INT	NULL)