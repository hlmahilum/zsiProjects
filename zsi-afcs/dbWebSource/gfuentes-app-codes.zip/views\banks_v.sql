






create VIEW [dbo].[banks_v]
AS 
SELECT *
FROM zsi_crm.dbo.banks where is_active='Y'




