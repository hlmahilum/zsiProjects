CREATE VIEW dbo.civil_statuses_v
AS
SELECT        civil_status_code, civil_status_desc
FROM            zsi_hcm.dbo.civil_statuses
