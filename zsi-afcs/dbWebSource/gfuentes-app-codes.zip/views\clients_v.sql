






CREATE VIEW [dbo].[clients_v]
AS 
SELECT *
FROM zsi_crm.dbo.clients where is_active='Y'




