

CREATE VIEW [dbo].[devices_v] AS
SELECT * FROM dbo.devices where is_active='Y'

