CREATE VIEW dbo.empl_types_v
AS
SELECT        empl_type_code, empl_type_desc
FROM            zsi_hcm.dbo.empl_types
