CREATE VIEW dbo.pay_types_v
AS
SELECT        pay_type_code, pay_type_desc
FROM            zsi_hcm.dbo.pay_types
