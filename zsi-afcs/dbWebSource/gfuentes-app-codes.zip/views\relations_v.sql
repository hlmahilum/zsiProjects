CREATE VIEW dbo.relations_v
AS
SELECT        relation_id, relation
FROM            zsi_hcm.dbo.relations
